const express = require('express');
const app = express();

app.use(express.json());
app.use(express.static('public'));
let users = {};

app.get('/', (req, res) => {
  res.send('NairaCash backend running 🚀');
});

// register
app.post('/register', (req, res) => {
  const { email, password } = req.body;

  users[email] = {
    email,
    password,
    balance: 0,
    transactions: [],
  };

  res.json({ message: 'Registered successfully' });
});

// login
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  app.post('/deposit', (req, res) => {
    const { email, amount } = req.body;

    if (!users[email]) {
      return res.json({ error: 'User not found' });
    }

    users[email].balance += amount;

    res.json({
      message: 'Deposit successful',
      balance: users[email].balance,
    });
  });
  const user = users[email];

  if (!user || user.password !== password) {
    return res.json({ error: 'Invalid login' });
  }

  res.json({ message: 'Login successful', user });
});

// get balance
app.get('/balance/:email', (req, res) => {
  const user = users[req.params.email];

  if (!user) return res.json({ error: 'User not found' });

  res.json({ balance: user.balance });
});

app.listen(3000, () => {
  console.log('Server running 🚀');
});
